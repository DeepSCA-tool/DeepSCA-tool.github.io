import ast
import gzip
import json
import math
import os
import pickle
import traceback

import requests
import chardet

def read_file_with_encoding_lines(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            return lines
    except Exception:
        return []
def read_file_with_encoding_content(file_path):
    with open(file_path, 'rb') as f:
        result = chardet.detect(f.read())
    encoding = result['encoding']

    with open(file_path, 'r', encoding=encoding) as f:
        content = f.read()

    return content
def read_jl(file_path):

    res=[]
    if not os.path.exists(file_path):
        return res
    with open(file_path, 'r') as json_file:
        line = json_file.readline()
        while line:
            line = line.strip()
            if line:
                try:
                    item = json.loads(line)
                    res.append(item)
                except Exception as e:
                    print(f"❌ json load error, line={line}, msg={str(e)}")
                    traceback.print_exc()
            line = json_file.readline()
    return res
def read_jl_dict(file_path):
    res={}
    if not os.path.exists(file_path):
        return res
    with open(file_path, 'r') as json_file:
        line = json_file.readline()
        while line:
            line = line.strip()
            if line:
                try:
                    item = json.loads(line)
                    res.update(item)
                except Exception as e:
                    print(f"❌ json load error, line={line}, msg={str(e)}")
                    traceback.print_exc()
            line = json_file.readline()
    return res
def read_jl_list(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        # Convert the content to a Python list
        python_list = ast.literal_eval(content)
    return python_list

def write_append_jl(file_path,data):

    with open(file_path, 'a+',encoding='utf-8') as json_file:
            try:
                json.dump(data, json_file)
                json_file.write('\n')
            except Exception as e:
                traceback.print_exc()
                print(f"❌ json write error, data={data}, msg={str(e)}")
def write_jl(file_path,data):
    with open(file_path, 'w',encoding='utf-8') as json_file:
            try:
                json.dump(data, json_file)
                json_file.write('\n')
            except Exception as e:
                traceback.print_exc()
                print(f"❌ json write error, data={data}, msg={str(e)}")
def write_line_jl(file_path,data):

    with open(file_path, 'w',encoding='utf-8') as json_file:
            try:
                for item in data:
                    json.dump(item, json_file)
                    json_file.write('\n')
            except Exception as e:
                traceback.print_exc()
                print(f"❌ json write error, data={data}, msg={str(e)}")
def write_line_jl_append(file_path,data):

    with open(file_path, 'a+',encoding='utf-8') as json_file:
            try:
                for item in data:
                    json.dump(item, json_file)
                    json_file.write('\n')
            except Exception as e:
                traceback.print_exc()
                print(f"❌ json write error, data={data}, msg={str(e)}")



def get_website(url,headers=None):
    proxy = {
        'http': 'http://127.0.0.1:10809',
        'https': 'http://127.0.0.1:10809'
    }
    if headers is None:
        headers = {}
    try:
        response = requests.get(url, proxies=proxy,headers=headers)
        if response.status_code==200:
            return response
    except Exception as e:
        traceback.print_exc()
def split_list( list, n):
    step_count = math.ceil(len(list) / n)
    for i in range(0, len(list), step_count):
        end = i + step_count
        if end > len(list):
            end = len(list)
        yield list[i:end]
def compress_dict(data):
    serialized_data = pickle.dumps(data)
    return gzip.compress(serialized_data)

def decompress_dict(compressed_data):
    serialized_data = gzip.decompress(compressed_data)
    return pickle.loads(serialized_data)

if __name__ == "__main__":
    res=read_jl(r"\oss_dataset_construction\data_out\alloss.jl")
    print(len(res))
    for item in res:
        print(item)
