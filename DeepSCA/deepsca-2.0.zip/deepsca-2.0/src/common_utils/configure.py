"""
"""

import os
import yaml
import logging

g_cur_dir = os.path.dirname(os.path.abspath(__file__))
father_path = os.path.dirname(g_cur_dir)
CONFIG_FILE_PATH = os.path.join(father_path, 'config.yml')

ORI_Harmony_FOLDER = os.path.join("open-harmony","harmony_source_repos")
All_DEP_FOLDER = os.path.join("open-harmony","all_repos_deps")
OSS_DATASET_REPO=os.path.join("open-harmony","oss_dataset_repos")
OSS_DATASET_SIG=os.path.join("open-harmony","oss_dataset_sigs")
OSS_ComponentDB=os.path.join("open-harmony","oss_componentdb")
construct_OSSDB= os.path.join("open-harmony","ossdb_construct")
construct_Component=os.path.join("open-harmony","component_construct")
Centris_Data=os.path.join("open-harmony","centris_db")
class LoadConfig(object):
    __shared_state = {}  # Borg design pattern, shared state
    configures = {}

    def __init__(self):
        self.__dict__ = self.__shared_state
        if not self.configures:
            with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as file:
                all_configures = yaml.safe_load(file)
                if 'env' in all_configures:
                    env_name = all_configures['env']
                    if env_name in all_configures:
                        self.configures = all_configures[env_name]
                else:
                    self.configures = {}
        if "local_data_path" in self.configures:
            self.configures['harmony_src'] = os.path.join(self.configures['local_data_path'], ORI_Harmony_FOLDER)
            self.configures['all_dep'] = os.path.join(self.configures['local_data_path'], All_DEP_FOLDER)
            self.configures['centris']=os.path.join(self.configures['local_data_path'], Centris_Data)
            self.configures['dataset_repo'] = os.path.join(self.configures['local_data_path'],OSS_DATASET_REPO)
            self.configures['dataset_sig'] = os.path.join(self.configures['local_data_path'], OSS_DATASET_SIG)
            self.configures['ossdb_construct'] = os.path.join(self.configures['local_data_path'],construct_OSSDB )
            self.configures['component_construct'] = os.path.join(self.configures['local_data_path'],
                                                              construct_Component)


configure = LoadConfig()
CONFIG = configure.configures