"""
"""
import math
import multiprocessing
import os
import re
import subprocess
import traceback
from functools import reduce

import tlsh
from scipy.stats import shapiro, chisquare
from tqdm import tqdm
from src.common_utils.logger import logger
from src.common_utils import configure
from src.common_utils.utils_file import write_append_jl, write_line_jl, read_file_with_encoding_lines
from collections import Counter, defaultdict
from src.operate_db.Family import Family
from src.operate_db.InitialSig import InitialSig
from src.operate_db.InitialSig_clean import InitialSig_clean
from src.operate_db.RepoFunction_db import RepoFunction
from src.operate_db.VerWeight import VerWeight
from src.operate_db.test.GT import GroundTruth

g_cur_dir = os.path.dirname(os.path.abspath(__file__))
father_path = os.path.dirname(g_cur_dir)
ctagsPath		= configure.CONFIG['ctags_path']
resultPath=os.path.join(g_cur_dir, "data_out")



class Detector:
    family = Family()
    initialSig=InitialSig_clean()
    repoFunction=RepoFunction()
    verWeight = VerWeight()
    def __init__(self,func_theta,file_theta,oss_theta):
        self.file_theta =file_theta
        self.oss_theta = oss_theta
        self.func_theta=func_theta

    def get_all_familys(self):
        res=self.family.get_data({},{'family_number':1})
        return res
    def get_ver_funccnt(self,ver_weight,sig_full_name,ver_common):
        querylist=[sig_full_name+"@@"+tag for tag in ver_weight ]
        tag_funccnt=defaultdict(tuple)
        res=self.repoFunction.get_data({"sig_full_tag_name":  {"$in": querylist}},{'func_cnt':1,'sig_full_tag_name':1})
        if len(res)!=0:
            for item in res:
                parts = item['sig_full_tag_name'].split("@@")
                if len(parts) > 1:
                    tag_name = parts[1]
                    tag_funccnt[tag_name]=(ver_weight[tag_name],float(ver_common[tag_name]/item['func_cnt']))
            return tag_funccnt
        else:
            return None


    def split_list(self, list, n):
        step_count = math.ceil(len(list) / n)
        for i in range(0, len(list), step_count):
            end = i + step_count
            if end > len(list):
                end = len(list)
            yield list[i:end]
    def get_ver_repo(self,tag,sig_full_name):
        return self.repoFunction.get_one_tagfunc({"sig_full_tag_name":sig_full_name+"@@"+tag},{})[0]['tag_func']


    def removeComment(self,string):
        # Code for removing C/C++ style comments. (Imported from VUDDY and ReDeBug.)
        # ref: https://github.com/squizz617/vuddy
        c_regex = re.compile(
            r'(?P<comment>//.*?$|[{}]+)|(?P<multilinecomment>/\*.*?\*/)|(?P<noncomment>\'(\\.|[^\\\'])*\'|"(\\.|[^\\"])*"|.[^/\'"]*)',
            re.DOTALL | re.MULTILINE)
        return ''.join([c.group('noncomment') for c in c_regex.finditer(string) if c.group('noncomment')])

    # Generate TLSH
    def computeTlsh(self,string):
        string = str.encode(string)
        hs = tlsh.forcehash(string)
        return hs

    def normalize(self,string):
        # Code for normalizing the input string.
        # LF and TAB literals, curly braces, and spaces are removed,
        # and all characters are lowercased.
        return ''.join(
            string.replace('\n', '').replace('\r', '').replace('\t', '').replace('{', '').replace('}', '').split(
                ' ')).lower()

    def hashing(self,repoPath):
        # This function is for hashing C/C++ functions
        # Only consider ".c", ".cc", and ".cpp" files

        possible = (".c", ".cc", ".cpp")

        fileCnt = 0
        funcCnt = 0
        lineCnt = 0

        resDict = {}

        for path, dir, files in os.walk(repoPath):
            for file in files:
                filePath = os.path.join(path, file)

                if file.endswith(possible):
                    try:
                        lines = read_file_with_encoding_lines(filePath)
                        if not lines:
                            print(f"[SKIP] Failed to read (encoding issue): {filePath}")
                            continue
                        # Execute Ctgas command
                        functionList = subprocess.check_output(
                            ctagsPath + ' -f - --kinds-C=* --fields=neKSt "' + filePath + '"', stderr=subprocess.STDOUT,
                            shell=True).decode('utf-8', errors='replace')
                        allFuncs = str(functionList).split('\n')
                        func = re.compile(r'(function)')
                        number = re.compile(r'(\d+)')
                        funcSearch = re.compile(r'{([\S\s]*)}')
                        tmpString = ""
                        funcBody = ""

                        fileCnt += 1

                        for i in allFuncs:
                            elemList = re.sub(r'[\t\s ]{2,}', '', i)
                            elemList = elemList.split('\t')
                            funcBody = ""

                            if i != '' and len(elemList) >= 8 and func.fullmatch(elemList[3]):
                                funcStartLine = int(number.search(elemList[4]).group(0))
                                funcEndLine = int(number.search(elemList[7]).group(0))

                                tmpString = ""
                                tmpString = tmpString.join(lines[funcStartLine - 1: funcEndLine])

                                if funcSearch.search(tmpString):
                                    funcBody = funcBody + funcSearch.search(tmpString).group(1)
                                else:
                                    funcBody = " "

                                funcBody = self.removeComment(funcBody)
                                funcBody = self.normalize(funcBody)
                                funcHash = self.computeTlsh(funcBody)

                                if len(funcHash) == 72 and funcHash.startswith("T1"):
                                    funcHash = funcHash[2:]
                                elif funcHash == "TNULL" or funcHash == "" or funcHash == "NULL":
                                    continue

                                storedPath = os.path.relpath(filePath,repoPath)
                                if funcHash not in resDict:
                                    resDict[funcHash] = []
                                resDict[funcHash].append((storedPath,funcStartLine,funcEndLine))

                                lineCnt += len(lines)
                                funcCnt += 1

                    except subprocess.CalledProcessError as e:
                        print("Parser Error:", e)
                        continue
                    except Exception as e:
                        print("Subprocess failed", e)
                        continue
                else:
                    pass

        return resDict, fileCnt, funcCnt, lineCnt

    def path_weight_func_count(self,inputDict,predictedVer_repo,func_feature):
        path_weight=defaultdict(int)
        used = 0
        unused = 0
        modified = 0
        strChange = False
        used_func=[]
        report_path=defaultdict(list)
        for ohash in predictedVer_repo:
            flag = 0
            if ohash in func_feature:
                if ohash in inputDict:
                    used += 1
                    used_func.append(ohash)
                    for storePath,funcStartLine,funcEndLine in inputDict[ohash]:
                        report_path[str(storePath)].append([funcStartLine,funcEndLine,list(predictedVer_repo[ohash])[0]])

                    nflag = 0
                    for opath in predictedVer_repo[ohash]:
                        for tpath in inputDict[ohash]:
                            if opath in tpath:
                                nflag = 1
                    if nflag == 0:
                        strChange = True

                    flag = 1

                else:
                    for thash in inputDict:
                        score = tlsh.diffxlen(ohash, thash)
                        if int(score) <= 30:
                            modified += 1
                            used_func.append(thash)
                            for storePath, funcStartLine, funcEndLine in inputDict[thash]:
                                report_path[str(storePath)].append([funcStartLine, funcEndLine, list(predictedVer_repo[ohash])[0]])

                            nflag = 0
                            for opath in predictedVer_repo[ohash]:
                                for tpath in inputDict[thash]:
                                    if opath in tpath:
                                        nflag = 1
                            if nflag == 0:
                                strChange = True

                            flag = 1

                            break
                if flag == 0:
                    unused += 1
                else:
                    for path in predictedVer_repo[ohash]:
                        path_weight[path] += 1
        return path_weight,used,unused,modified,strChange,used_func,report_path

    def path_all_func_count(self, predictedVer_repo,func_feature,theta=1.0):
        path_all = defaultdict(int)
        for hashFunction, info in predictedVer_repo.items():
            if hashFunction in func_feature:
                for path in info:
                    path_all[path] += 1*theta
        return path_all

    def calculate_func_reuse_ratio(self, path_weight, path_all):
        file_reuse_ratio = defaultdict(float)
        file_reuse_ratio_data=defaultdict(float)
        for path, value in path_weight.items():
            ratio = float(value / path_all[path])
            if ratio > self.file_theta:
                if path not in file_reuse_ratio:
                    file_reuse_ratio[path] = ratio
        return file_reuse_ratio
    def Determine_version(self,commonFunc,inputDict,oss_all_func, candicate_oss):
        predictedVer=None
        weightFunc = self.verWeight.get_one_weight({'sig_full_name': candicate_oss}, {'weight': 1})[0]['weight']
        ver_weight = defaultdict(int)
        ver_common = defaultdict(int)
        reuse_path = []
        for hashFunction in commonFunc:
            reuse_path.extend(inputDict[hashFunction])
            tags = oss_all_func[hashFunction]
            for tag in tags:
                ver_weight[tag] += weightFunc[hashFunction]
                ver_common[tag] += 1
        tag_funccnt = self.get_ver_funccnt(ver_weight, candicate_oss, ver_common)
        if tag_funccnt is not None:
            sortedByWeight = sorted(tag_funccnt.items(), key=lambda x: (x[1][0], x[1][1], x[0]), reverse=True)
            predictedVer = sortedByWeight[0][0]
        return predictedVer,ver_weight,reuse_path

    def target_path_all(self,inputDuict):
        path_all=defaultdict(int)
        for func ,info in inputDuict.items():
            for path,funcStartLine,funcEndLine in info:
                path_all[path]+=1
        return path_all
    def chisp(self,file_reuse_ratio,alpha):
        sorted_counts = dict(sorted(file_reuse_ratio.items(), key=lambda item: item[1]))
        sample_data = []
        for key, value in sorted_counts.items():
            sample_data.append(value)
        chi2_stat, chi2_p = chisquare(sample_data)

        if chi2_p < alpha:
            return False
        else:
            return True
    def is_reuse_standard(self,commonFunc,inputDict,oss_all_func,candicate_oss):
        report_data=None
        used_func=[]

        predictedVer, ver_weight, reuse_path = self.Determine_version(commonFunc, inputDict, oss_all_func, candicate_oss)
        if predictedVer is not None:
            predictedVer_repo = self.get_ver_repo(predictedVer, candicate_oss)
            path_weight, used, unused, modified, strChange, used_func, report_path = self.path_weight_func_count(
                inputDict, predictedVer_repo, oss_all_func)
            path_all = self.path_all_func_count(predictedVer_repo, oss_all_func)
            reuse_path_total = 0
            for key, value in path_weight.items():
                if value != 0:
                    reuse_path_total += 1
            file_reuse_ratio= self.calculate_func_reuse_ratio(path_weight, path_all)
            ratio = float(len(file_reuse_ratio) / len(path_all))
            if ratio > self.oss_theta:
                IsReuse = True
                sort_reuse_path = dict(sorted(report_path.items(), key=lambda x: len(x[1]), reverse=True))
                report_data = {
                    'name': candicate_oss,
                    'version': predictedVer,
                    'path': sort_reuse_path,
                    'used_same': str(used),
                    'used_modified': str(modified),
                    'used_strChange': str(strChange),
                    'unused': unused,
                    'label': 3
                }
        return report_data,used_func


    def is_subset_of_components(self,target_path_weight,targetpath_all,commonFunc,inputDict,oss_all_func,candicate_oss):
        used_func=[]
        file_reuse_ratio = self.calculate_func_reuse_ratio(target_path_weight, targetpath_all)
        ratio = float(len(file_reuse_ratio) / len(targetpath_all))
        report_data=None
        if ratio > self.file_theta:
            predictedVer, ver_weight, reuse_path = self.Determine_version(commonFunc, inputDict, oss_all_func, candicate_oss)
            if predictedVer is not None:
                predictedVer_repo = self.get_ver_repo(predictedVer, candicate_oss)
                path_weightreuse, used, unused, modified, strChange, used_func, report_path = self.path_weight_func_count(
                    inputDict,
                    predictedVer_repo,
                    oss_all_func)
                sort_reuse_path = dict(sorted(report_path.items(), key=lambda x: len(x[1]), reverse=True))
                report_data = {
                    'name': candicate_oss,
                    'version': predictedVer,
                    'path': sort_reuse_path,
                    'used_same': str(used),
                    'used_modified': str(modified),
                    'used_strChange': str(strChange),
                    'unused': unused,
                    'label':0
                }
        return report_data,used_func
    def identify_single_tpl(self,sig_full_name,commonFuncs,target_path_weight,targetpath_all,target_hash,oss_feature=None,family_used_func=None):
        report_data=None
        used_func=[]
        if oss_feature is None:
            oss_feature = self.initialSig.get_one_feature({'sig_full_name': sig_full_name}, {}) # 获取候选oss的特征
        if family_used_func is None:
            family_used_func=set()
        if len(oss_feature)>0:
            oss_feature=oss_feature[0]
            oss_all_func = oss_feature['func_feature']
            for hash in family_used_func:
                if hash in oss_all_func:
                    del oss_all_func[hash]
            oss_ver_cnt = oss_feature['ver_cnt']
            oss_url=oss_feature['oss_url']
            func_cnt=oss_feature['func_feature_cnt']
            totOSSFuncs = float(len(oss_all_func) / oss_ver_cnt)
            if len(commonFuncs) != 0:
                if report_data is None:
                    if float(len(commonFuncs) / totOSSFuncs) >=self.func_theta:
                        report_data, used_func = self.is_reuse_standard(commonFuncs, target_hash, oss_all_func,sig_full_name)
                if report_data is not None:
                    report_data['url']=oss_url
                    report_data['func_cnt']=func_cnt
        else:
            print(f"error: {sig_full_name}")
        return report_data,used_func


    def identify_family(self,target_hash,family_feature,targetpath_all):
        report_datas=[]
        tpl_reuse=[]
        family_number=family_feature['family_number']
        family_member=family_feature['family_member']
        family_ancestor=family_feature['family_ancestor']
        family_func_index=family_feature['family_func_index']
        family_func_weight=family_feature['family_func_weight']
        tpl_reuse_weight=defaultdict(float)
        tpl_reuse_funcs=defaultdict(set)
        target_path_weight = defaultdict(int)
        commonFuncs=0
        for hash in target_hash:
            if hash in family_func_index:
                for path, funcStartLine, funcEndLine in target_hash[hash]:
                    target_path_weight[path] += 1
                commonFuncs+=1
                for tpl in family_func_index[hash]:
                    tpl_reuse_weight[tpl]+=family_func_weight[hash]
                    tpl_reuse_funcs[tpl].add(hash)
        ratio=float(commonFuncs/len(family_func_index))
        if ratio>0:
            family_used_func=[]
            if len(tpl_reuse_funcs[family_ancestor])!=0:
                report_data, used_func = self.identify_single_tpl(family_ancestor, tpl_reuse_funcs[family_ancestor], target_path_weight, targetpath_all,target_hash)
                if report_data is not None:
                    family_used_func.extend(used_func)
                    report_data['family_number'] = family_number
                    report_data['family_member'] = family_member
                    report_datas.append(report_data)
                    tpl_reuse.append(family_ancestor)
             sorted_tpl_reuse_weight = dict(sorted(tpl_reuse_weight.items(), key=lambda item: item[1], reverse=True))
            for tpl,weight in sorted_tpl_reuse_weight.items():
                if tpl in tpl_reuse:
                    continue
                reuse_func=set(set(tpl_reuse_funcs[tpl]) - set(family_used_func))
                report_data,used_func=self.identify_single_tpl(tpl,reuse_func,target_path_weight,targetpath_all,target_hash,family_used_func=family_used_func)
                if report_data==None:
                    break
                else:
                    family_used_func.extend(used_func)
                    report_data['family_number'] = family_number
                    report_data['family_member'] = family_member
                    report_datas.append(report_data)
                    tpl_reuse.append(tpl)
        return report_datas

    def detector(self, args):
        idx, listarr, inputDictO, already_func, lock = args
        inputDict = inputDictO.copy()
        final_res = []

        targetpath_all = self.target_path_all(inputDict)

        for family in listarr:
            try:
                family_feature = self.family.get_feature({'family_number': family['family_number']}, {})[0]
                if len(inputDict) == 0:
                    break

                if len(family_feature['family_member']) > 1:
                    report_datas = self.identify_family(inputDict, family_feature, targetpath_all)
                    final_res.extend(report_datas)
                else:
                    tpl = family_feature['family_member'][0]
                    tpl_feature = self.initialSig.get_one_feature({'sig_full_name': tpl}, {})
                    tpl_func_feature = tpl_feature[0]['func_feature']
                    commonFuncs = set()
                    target_path_weight = defaultdict(int)

                    for hash in inputDict:
                        if hash in tpl_func_feature:
                            for path, funcStartLine, funcEndLine in inputDict[hash]:
                                target_path_weight[path] += 1
                            commonFuncs.add(hash)

                    report_data, used_func = self.identify_single_tpl(
                        family_feature['family_member'][0],
                        commonFuncs,
                        target_path_weight,
                        targetpath_all,
                        inputDict,
                        oss_feature=tpl_feature
                    )

                    if report_data is not None:
                        final_res.append(report_data)
            except Exception as e:
                traceback.print_exc()
        return final_res


    def detector_main(self,inputDict,numProcess):
        logger.info("[+] start detector")
        manager = multiprocessing.Manager()
        final_res = []
        already_func = manager.list()
        lock = manager.Lock()
        all_familys = self.get_all_familys()
        with multiprocessing.Pool(processes=numProcess) as pool:
            results=pool.map(self.detector,
                     [(idx + 1, list_arr, inputDict, already_func,lock) for
                      idx, list_arr in enumerate(self.split_list(all_familys, numProcess))])
        for result in results:
            final_res.extend(result)
        if len(final_res) != 0:
            sortfinalres = sorted(list(final_res), key=lambda x: x['used_same'], reverse=True)
            return sortfinalres
        else:
            return None

if __name__ == "__main__":
    detector=Detector(0.1,0.7,0.6)
    target_src_repo='opharmony_third_party_glslang'
    harmonyProjects =GroundTruth()
    resDict=harmonyProjects.get_one_hashing({'projectname':"opharmony_third_party_glslang"},{'projectname':1,"hashing":1})[0]['hashing']
    if len(resDict)!=0:
        final_res=detector.detector_main(resDict,8)
        if final_res is not None:
            write_line_jl(os.path.join(resultPath, target_src_repo + ".jl"), final_res)
    else:
        print("error: non-C/C++ source code!")
