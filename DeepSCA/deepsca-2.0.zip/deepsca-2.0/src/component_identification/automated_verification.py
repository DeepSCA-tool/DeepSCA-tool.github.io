"""


"""
import difflib
import os
import traceback

from src.common_utils.utils_file import read_jl, write_line_jl
from src.operate_db.Component import Component as Component


class Verification:
    component=Component()
    def __init__(self,theta):
        self.similar_theta = theta

    def find_common_nodes(self,path1, path2):
        parts1 = path1.split("\\")
        parts2 = path2.split("\\")


        common_nodes = set(parts1).intersection(parts2)

        return common_nodes
    def find_short_path(self, start_directory, target_short_path):
        for root, _, files in os.walk(start_directory):
            for file in files:
                full_path = os.path.join(root, file).lower()

                if target_short_path in full_path:
                    return os.path.relpath(full_path,start_directory)
        return None

    def check_h_file(self, target_src_path, target_head_file):
        for root, dirs, files in os.walk(target_src_path):
            for file in files:
                if file.endswith(".h"):
                    matcher_headfile = difflib.SequenceMatcher(None, file.lower(), target_head_file)
                    similarity_ratio_headfile = matcher_headfile.ratio()
                    if similarity_ratio_headfile >= self.similar_theta:
                        return os.path.relpath(os.path.join(root, file),target_src_path)
        return None
    def analysis_common(self,report,target_src_path,projectname):

        for data in report:
            reliability=0
            try:
                report_name = data['name']
                report_url = data['url']
                report_paths = data['path']
                data['verify'] = []
                reponame = report_url.split('/')[-1]
                matcher = difflib.SequenceMatcher(None, projectname, reponame)
                similarity_ratio = matcher.ratio()
                print(reponame, projectname, similarity_ratio)
                if similarity_ratio >= self.similar_theta:
                    reliability += 2
                    data['verify'].append((report_name, "oss name same projectnanme"))
                break_flag = False
                for path in report_paths:
                    path_node = path.lower().split("\\")
                    for node in path_node:

                        node=node.replace(".cc","")
                        node = node.replace(".cpp", "")
                        node = node.replace(".c", "")
                        matcher = difflib.SequenceMatcher(None, node, reponame)
                        similarity_ratio = matcher.ratio()
                        if similarity_ratio >= self.similar_theta:
                            reliability+=2
                            data['verify'].append((path,"path contain oss name"))
                            break_flag = True
                            break
                    if break_flag:
                        break

                target_head_file = reponame + ".h"
                head_file_res = self.check_h_file(target_src_path, target_head_file)
                if head_file_res is not None:
                    reliability += 2
                    data['verify'] .append( (head_file_res,"has ossname.h"))
                break_iner_flag = False
                metadata_file = self.component.get_data({'sig_full_name':report_name},{'metafile':1})
                if len(metadata_file)!=0:
                    metadata_file=metadata_file[0]
                    metadata_path = [os.path.join(reponame, file) for file in metadata_file['metafile']]
                    for path in metadata_path:
                        res = self.find_short_path(target_src_path, path.lower())
                        if res is not None:
                            reliability += 1
                            data['verify'].append((res,'has oss metafile'))
                            break_iner_flag = True
                            break
                if len(data['verify'])==0:
                    reuse_node=None
                    for key, value in report_paths.items():
                        print(key,value)
                        for item in value:
                            print(item)
                            reuse_node = self.find_common_nodes(key, item[2])
                    data['verify'].append((list(reuse_node), 'require manual analysis'))
            except Exception as e:
                print("Parser Error:", e)
                traceback.print_exc()
                continue
            data['reliability']=reliability
        return report


if __name__ == "__main__":
    verification=Verification()
    resultPath=input("resultPath:")
    target_src_path=input("target_src_path:")
    res = read_jl(os.path.join(resultPath))
    if len(res) != 0:
        analysis_detect = verification.analysis_common(res, target_src_path)
        print(len(analysis_detect))
        write_line_jl(os.path.join(r"\src\component_identification\data_out",  "verify.jl"), analysis_detect)