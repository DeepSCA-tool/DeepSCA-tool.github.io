

# src/ast_handler.py

import tree_sitter_cpp as tscpp
from tree_sitter import Language, Parser
from .config import Config


class ASTHandler:
    def __init__(self):

        CPP_LANGUAGE = Language(tscpp.language())
        self.parser = Parser(CPP_LANGUAGE)

    def _get_text(self, src_bytes, node):
        return src_bytes[node.start_byte:node.end_byte].decode('utf-8', errors='ignore')

    def parse_definitions(self, file_path):

        definitions = {}
        try:
            with open(file_path, 'rb') as f:
                src = f.read()
            tree = self.parser.parse(src)
            self._traverse_defs(tree.root_node, src, [], definitions)
        except Exception:
            pass
        return definitions

    def _traverse_defs(self, node, src, scope_stack, defs):

        if node.type == 'namespace_definition':
            name_node = node.child_by_field_name('name')
            if name_node:
                ns_name = self._get_text(src, name_node)
                new_stack = scope_stack + [ns_name]
                for child in node.children:
                    self._traverse_defs(child, src, new_stack, defs)
            return


        if node.type in ('class_specifier', 'struct_specifier'):
            name_node = node.child_by_field_name('name')
            if name_node:
                name = self._get_text(src, name_node)
                fqn = "::".join(scope_stack + [name])
                defs[fqn] = 'type'

                new_stack = scope_stack + [name]
                body = node.child_by_field_name('body')
                if body:
                    for child in body.children:
                        self._traverse_defs(child, src, new_stack, defs)
            return


        if node.type == 'declaration':

            is_extern = False
            for child in node.children:
                if child.type == 'storage_class_specifier' and self._get_text(src, child) == 'extern':
                    is_extern = True
                    break

            if is_extern:
                return

            var_name = None

            for child in node.children:

                if child.type == 'init_declarator':
                    declarator = child.child_by_field_name('declarator')
                    if declarator:

                        var_name = self._extract_identifier(src, declarator)
                    break

                elif child.type == 'identifier':

                    var_name = self._get_text(src, child)
                    break

                elif child.type in ('pointer_declarator', 'array_declarator', 'reference_declarator'):
                    var_name = self._extract_identifier(src, child)
                    break

            if var_name:
                fqn = "::".join(scope_stack + [var_name])
                defs[fqn] = 'variable'
            return

        for child in node.children:
            self._traverse_defs(child, src, scope_stack, defs)

    def _extract_identifier(self, src, node):

        if node.type == 'identifier':
            return self._get_text(src, node)


        child = node.child_by_field_name('declarator')
        if child:
            return self._extract_identifier(src, child)

        for child in node.children:

            if child.type not in ('*', '&', '[', ']', '='):
                res = self._extract_identifier(src, child)
                if res: return res
        return None

    def find_usages(self, file_path, symbol_index):

        usages = []
        try:
            with open(file_path, 'rb') as f:
                src = f.read()
            tree = self.parser.parse(src)
            self._traverse_usages(tree.root_node, src, [], symbol_index, usages)
        except Exception:
            pass
        return usages

    def _traverse_usages(self, node, src, scope_stack, index, usages):

        if node.type == 'namespace_definition':
            name_node = node.child_by_field_name('name')
            if name_node:
                ns_name = self._get_text(src, name_node)
                new_stack = scope_stack + [ns_name]
                for child in node.children:
                    self._traverse_usages(child, src, new_stack, index, usages)
            return

        if node.type == 'type_identifier':
            raw_name = self._get_text(src, node)
            if raw_name not in Config.IGNORED_SYMBOLS:

                temp_stack = list(scope_stack)
                while True:
                    candidate_fqn = "::".join(temp_stack + [raw_name])
                    if candidate_fqn in index:

                        target_files = index[candidate_fqn]
                        for tf in target_files:
                            usages.append((candidate_fqn, tf))
                        break

                    if not temp_stack:
                        break
                    temp_stack.pop()

        for child in node.children:
            self._traverse_usages(child, src, scope_stack, index, usages)
