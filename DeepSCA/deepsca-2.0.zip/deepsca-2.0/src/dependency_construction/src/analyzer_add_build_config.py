import os
import re
import json
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor

from .config import Config
from .utils import normalize_path, logger
from .ast_handler import ASTHandler


class ProjectAnalyzer:
    def __init__(self, root_dir):
        self.root = normalize_path(root_dir)
        self.all_files = []
        self.symbol_table = defaultdict(list)
        self.dependencies = []
        self.include_paths = set()
        self.dynamic_deps = []
        self.include_paths.add(self.root)
        self.file_map = defaultdict(list)
        self.ast_engine = ASTHandler()

    def _scan_files(self):
        logger.info(f"Scanning files: {self.root}")
        for root, _, files in os.walk(self.root):
            if os.path.basename(root).lower() in {'include', 'inc', 'headers', 'api', 'public', 'src'}:
                self.include_paths.add(normalize_path(root))
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                full_path = normalize_path(os.path.join(root, f))
                self.file_map[f].append(full_path)
                if ext in Config.SOURCE_EXTS:
                    self.all_files.append(full_path)
        logger.info(f"Found {len(self.all_files)} source files")

    def _step1_extract_build_config(self):
        logger.info("Scanning build configurations (CMake/Make/GN/Bazel/VS)...")
        re_cmake_inc = re.compile(r'include_directories\s*\(([^)]+)\)', re.IGNORECASE | re.DOTALL)
        re_cmake_link = re.compile(r'target_link_libraries\s*\(([^)]+)\)', re.IGNORECASE | re.DOTALL)
        re_gn_inc = re.compile(r'include_dirs\s*=\s*\[(.*?)]', re.DOTALL)
        re_gn_deps = re.compile(r'deps\s*=\s*\[(.*?)]', re.DOTALL)
        re_bazel_inc = re.compile(r'includes\s*=\s*\[(.*?)]', re.DOTALL)
        re_bazel_deps = re.compile(r'deps\s*=\s*\[(.*?)]', re.DOTALL)
        re_meson_inc = re.compile(r'include_directories\s*\(([^)]+)\)', re.IGNORECASE)
        re_make_inc = re.compile(r'-I\s*(\S+)')
        re_make_link = re.compile(r'-l\s*(\S+)')
        re_vs_inc = re.compile(r'<AdditionalIncludeDirectories>(.*?)</AdditionalIncludeDirectories>', re.IGNORECASE)
        IGNORE_KEYWORDS = {'PUBLIC', 'PRIVATE', 'INTERFACE', 'sources', 'true', 'false'}
        for root, _, files in os.walk(self.root):
            if 'CMakeLists.txt' in files:
                self._parse_regex_file(os.path.join(root, 'CMakeLists.txt'), root, re_cmake_inc, re_cmake_link, IGNORE_KEYWORDS, False)
            if 'BUILD.gn' in files:
                self._parse_regex_file(os.path.join(root, 'BUILD.gn'), root, re_gn_inc, re_gn_deps, IGNORE_KEYWORDS, True)
            if 'BUILD' in files or 'BUILD.bazel' in files:
                target = 'BUILD' if 'BUILD' in files else 'BUILD.bazel'
                self._parse_regex_file(os.path.join(root, target), root, re_bazel_inc, re_bazel_deps, IGNORE_KEYWORDS, True)
            if 'meson.build' in files:
                self._parse_regex_file(os.path.join(root, 'meson.build'), root, re_meson_inc, None, IGNORE_KEYWORDS, False)
            if 'Makefile' in files:
                self._parse_makefile(os.path.join(root, 'Makefile'), root, re_make_inc, re_make_link)
            for f in files:
                if f.endswith('.vcxproj'):
                    self._parse_vcxproj(os.path.join(root, f), root, re_vs_inc)
        logger.info(f"Extracted {len(self.include_paths)} include search paths")

    def _parse_regex_file(self, filepath, root_dir, inc_re, link_re, ignore_set, is_list_content=False):
        try:
            with open(filepath, 'r', errors='ignore') as f:
                content = f.read()
                if inc_re:
                    for match in inc_re.findall(content):
                        raw_paths = match if not is_list_content else match.replace('"', '').replace("'", '').replace(',', ' ')
                        for path in raw_paths.split():
                            if '$' not in path and path not in ignore_set:
                                if path.startswith('//'):
                                    abs_p = normalize_path(os.path.join(self.root, path.lstrip('/')))
                                else:
                                    abs_p = normalize_path(os.path.join(root_dir, path))
                                if os.path.exists(abs_p):
                                    self.include_paths.add(abs_p)
                if link_re:
                    for match in link_re.findall(content):
                        raw_libs = match if not is_list_content else match.replace('"', '').replace("'", '').replace(',', ' ')
                        for lib in raw_libs.split():
                            if '$' not in lib and lib not in ignore_set and len(lib) > 1:
                                self.dynamic_deps.append({
                                    'source_module': normalize_path(root_dir),
                                    'target_lib': lib,
                                    'type': 'build_dep'
                                })
        except:
            pass

    def _parse_makefile(self, filepath, root_dir, inc_re, link_re):
        try:
            with open(filepath, 'r', errors='ignore') as f:
                for line in f:
                    if line.strip().startswith('#'): continue
                    for match in inc_re.findall(line):
                        abs_p = normalize_path(os.path.join(root_dir, match))
                        if os.path.exists(abs_p): self.include_paths.add(abs_p)
                    for match in link_re.findall(line):
                        self.dynamic_deps.append(
                            {'source_module': normalize_path(root_dir), 'target_lib': match, 'type': 'dynamic_link'})
        except:
            pass

    def _parse_vcxproj(self, filepath, root_dir, inc_re):
        try:
            with open(filepath, 'r', errors='ignore') as f:
                content = f.read()
                for match in inc_re.findall(content):
                    for path in match.split(';'):
                        path = path.strip()
                        if path and '%' not in path:
                            abs_p = normalize_path(os.path.join(root_dir, path))
                            if os.path.exists(abs_p): self.include_paths.add(abs_p)
        except:
            pass

    def _step2_build_symbol_index(self):
        logger.info("Building AST symbol index...")
        for f_path in self.all_files:
            defs = self.ast_engine.parse_definitions(f_path)
            for fqn, _ in defs.items():
                self.symbol_table[fqn].append(f_path)
        logger.info(f"Indexing complete, found {len(self.symbol_table)} unique symbols")

    def _step3_resolve_implicit_deps(self):
        logger.info("Resolving implicit dependencies (scope-based matching)...")
        count = 0
        for f_path in self.all_files:
            usages = self.ast_engine.find_usages(f_path, self.symbol_table)
            for fqn, target_file in usages:
                if target_file != f_path:
                    self.dependencies.append({
                        'source': f_path,
                        'target': target_file,
                        'type': 'implicit_ast',
                        'label': fqn
                    })
                    count += 1
        logger.info(f"Discovered {count} implicit AST dependencies")

    def _resolve_include_path(self, current_file_dir, include_str):
        guess = normalize_path(os.path.join(current_file_dir, include_str))
        if os.path.exists(guess): return guess
        for search_path in self.include_paths:
            guess = normalize_path(os.path.join(search_path, include_str))
            if os.path.exists(guess): return guess
        basename = os.path.basename(include_str)
        candidates = self.file_map.get(basename)
        if candidates:
            return min(candidates, key=lambda x: (0 if 'include' in x.lower() else 1, len(x)))
        return None

    def _step4_resolve_includes(self):
        logger.info("Resolving #include dependencies...")
        count = 0
        for f_path in self.all_files:
            current_dir = os.path.dirname(f_path)
            try:
                with open(f_path, 'r', errors='ignore', encoding='utf-8') as f:
                    content = f.read()
                    includes = re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', content, re.MULTILINE)
                    for inc in includes:
                        target = self._resolve_include_path(current_dir, inc)
                        if target:
                            self.dependencies.append({
                                'source': f_path,
                                'target': target,
                                'type': 'include'
                            })
                            count += 1
            except:
                pass
        logger.info(f"Discovered {count} include dependencies")

    def _step5_attach_licenses(self):
        logger.info("Attaching license files...")
        count = 0
        dir_cache = {}
        for f_path in self.all_files:
            current_dir = os.path.dirname(f_path)
            license_file = None
            search_dir = current_dir
            while search_dir.startswith(self.root):
                if search_dir in dir_cache:
                    license_file = dir_cache[search_dir]
                    break
                found = False
                try:
                    for f in os.listdir(search_dir):
                        if any(p in f.lower() for p in Config.LICENSE_PATTERNS):
                            license_file = normalize_path(os.path.join(search_dir, f))
                            dir_cache[search_dir] = license_file
                            found = True
                            break
                except:
                    pass
                if found: break
                search_dir = os.path.dirname(search_dir)
            if license_file:
                self.dependencies.append({
                    'source': f_path,
                    'target': license_file,
                    'type': 'license'
                })
                count += 1
        logger.info(f"Attached {count} license relationships")

    def run(self):
        start_t = time.time()
        self._scan_files()
        self._step1_extract_build_config()
        self._step2_build_symbol_index()
        self._step3_resolve_implicit_deps()
        self._step4_resolve_includes()
        self._step5_attach_licenses()
        self._save_output()
        logger.info(f"Analysis completed in {time.time() - start_t:.2f}s")

    def _save_output(self):
        nodes = {}
        edges = []
        seen = set()

        def get_rel(p):
            try:
                return os.path.relpath(p, self.root).replace('\\', '/')
            except:
                return p.replace('\\', '/')

        for dep in self.dependencies:
            src_rel = get_rel(dep['source'])
            tgt_rel = get_rel(dep['target'])
            if src_rel not in nodes:
                nodes[src_rel] = {'id': src_rel, 'label': os.path.basename(src_rel), 'type': 'file'}
            t_type = 'license' if dep['type'] == 'license' else 'file'
            if tgt_rel not in nodes:
                nodes[tgt_rel] = {'id': tgt_rel, 'label': os.path.basename(tgt_rel), 'type': t_type}
            key = (src_rel, tgt_rel, dep['type'])
            if key not in seen:
                edge_obj = {'source': src_rel, 'target': tgt_rel, 'type': dep['type']}
                if 'label' in dep: edge_obj['symbol'] = dep['label']
                edges.append(edge_obj)
                seen.add(key)

        for d in self.dynamic_deps:
            src_rel = get_rel(d['source_module'])
            lib_name = d['target_lib']
            if src_rel not in nodes:
                nodes[src_rel] = {'id': src_rel, 'label': os.path.basename(src_rel), 'type': 'file'}
            if lib_name not in nodes:
                nodes[lib_name] = {'id': lib_name, 'label': lib_name, 'type': 'library'}
            key = (src_rel, lib_name, d['type'])
            if key not in seen:
                edges.append({'source': src_rel, 'target': lib_name, 'type': d['type']})
                seen.add(key)

        output = {
            'meta': {'root': self.root, 'timestamp': time.time()},
            'nodes': list(nodes.values()),
            'edges': edges
        }

        with open(Config.OUTPUT_FILE, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2)
        logger.info(f"Output saved to: {Config.OUTPUT_FILE}")