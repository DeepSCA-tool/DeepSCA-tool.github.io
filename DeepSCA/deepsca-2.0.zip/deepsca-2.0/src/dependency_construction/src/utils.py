
# src/utils.py

import os
import sys

def get_logger():

    class Logger:
        def info(self, msg):
            print(f"[INFO] {msg}")
        def error(self, msg):
            print(f"[ERROR] {msg}", file=sys.stderr)
    return Logger()

logger = get_logger()

def normalize_path(path):
    return os.path.abspath(path).replace('\\', '/')
