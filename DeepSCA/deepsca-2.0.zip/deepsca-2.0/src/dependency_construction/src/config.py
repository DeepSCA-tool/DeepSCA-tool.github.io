
# src/config.py

import multiprocessing


class Config:

    SOURCE_EXTS = {'.c', '.cc', '.cpp', '.cxx', '.h', '.hpp', '.hxx', '.inl'}

    LICENSE_PATTERNS = {'license', 'copying', 'notice', 'readme', 'mit', 'bsd', 'apache'}

    NUM_WORKERS = max(1, multiprocessing.cpu_count() - 1)

    IGNORED_SYMBOLS = {
        'int', 'char', 'void', 'float', 'double', 'long', 'short', 'bool',
        'unsigned', 'signed', 'auto', 'const', 'static', 'volatile',
        'size_t', 'std', 'string', 'vector', 'map', 'list', 'virtual', 'override'
    }

    OUTPUT_FILE = "project_dependency_graph.json"
