import os
import re
import json
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor

from .config import Config
from .utils import normalize_path, logger
from .ast_handler import ASTHandler


class ProjectAnalyzer:
    def __init__(self, root_dir):
        self.root = normalize_path(root_dir)
        self.all_files = []
        self.symbol_table = defaultdict(list)
        self.dependencies = []
        self.ast_engine = ASTHandler()

    def _scan_files(self):
        logger.info(f"Scanning files: {self.root}")
        for root, _, files in os.walk(self.root):
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                if ext in Config.SOURCE_EXTS:
                    self.all_files.append(normalize_path(os.path.join(root, f)))
        logger.info(f"Found {len(self.all_files)} source files")

    def _step1_build_symbol_index(self):
        logger.info("Building AST symbol index...")
        for f_path in self.all_files:
            defs = self.ast_engine.parse_definitions(f_path)
            for fqn, _ in defs.items():
                self.symbol_table[fqn].append(f_path)
        logger.info(f"Indexing complete, found {len(self.symbol_table)} unique symbols")

    def _step2_resolve_implicit_deps(self):
        logger.info("Resolving implicit dependencies (scope-based matching)...")
        count = 0
        for f_path in self.all_files:
            usages = self.ast_engine.find_usages(f_path, self.symbol_table)
            for fqn, target_file in usages:
                if target_file != f_path:
                    self.dependencies.append({
                        'source': f_path,
                        'target': target_file,
                        'type': 'implicit_ast',
                        'label': fqn
                    })
                    count += 1
        logger.info(f"Discovered {count} implicit AST dependencies")

    def _step3_resolve_includes(self):
        logger.info("Resolving #include dependencies...")
        name_map = defaultdict(list)
        for f in self.all_files:
            name_map[os.path.basename(f)].append(f)
        count = 0
        for f_path in self.all_files:
            try:
                with open(f_path, 'r', errors='ignore', encoding='utf-8') as f:
                    content = f.read()
                    includes = re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', content, re.MULTILINE)
                    for inc in includes:
                        target = None
                        guess = normalize_path(os.path.join(os.path.dirname(f_path), inc))
                        if guess in self.all_files:
                            target = guess
                        else:
                            candidates = name_map.get(os.path.basename(inc))
                            if candidates:
                                target = candidates[0]
                        if target:
                            self.dependencies.append({
                                'source': f_path,
                                'target': target,
                                'type': 'include'
                            })
                            count += 1
            except:
                pass
        logger.info(f"Discovered {count} include dependencies")

    def _step4_attach_licenses(self):
        logger.info("Attaching license files...")
        count = 0
        dir_cache = {}
        for f_path in self.all_files:
            current_dir = os.path.dirname(f_path)
            license_file = None
            search_dir = current_dir
            while search_dir.startswith(self.root):
                if search_dir in dir_cache:
                    license_file = dir_cache[search_dir]
                    break
                found = False
                try:
                    for f in os.listdir(search_dir):
                        if any(p in f.lower() for p in Config.LICENSE_PATTERNS):
                            license_file = normalize_path(os.path.join(search_dir, f))
                            dir_cache[search_dir] = license_file
                            found = True
                            break
                except:
                    pass
                if found:
                    break
                search_dir = os.path.dirname(search_dir)
            if license_file:
                self.dependencies.append({
                    'source': f_path,
                    'target': license_file,
                    'type': 'license'
                })
                count += 1
        logger.info(f"Attached {count} license relationships")

    def run(self):
        start_t = time.time()
        self._scan_files()
        self._step1_build_symbol_index()
        self._step2_resolve_implicit_deps()
        self._step3_resolve_includes()
        self._step4_attach_licenses()
        self._save_output()
        logger.info(f"Analysis completed in {time.time() - start_t:.2f}s")

    def _save_output(self):
        nodes = {}
        edges = []
        seen = set()

        def get_rel(p):
            try:
                return os.path.relpath(p, self.root).replace('\\', '/')
            except:
                return p

        for dep in self.dependencies:
            src_rel = get_rel(dep['source'])
            tgt_rel = get_rel(dep['target'])
            if src_rel not in nodes:
                nodes[src_rel] = {'id': src_rel, 'label': os.path.basename(src_rel), 'type': 'file'}
            t_type = 'license' if dep['type'] == 'license' else 'file'
            if tgt_rel not in nodes:
                nodes[tgt_rel] = {'id': tgt_rel, 'label': os.path.basename(tgt_rel), 'type': t_type}
            key = (src_rel, tgt_rel, dep['type'])
            if key not in seen:
                edge_obj = {
                    'source': src_rel,
                    'target': tgt_rel,
                    'type': dep['type']
                }
                if 'label' in dep:
                    edge_obj['symbol'] = dep['label']
                edges.append(edge_obj)
                seen.add(key)

        output = {
            'meta': {'root': self.root, 'timestamp': time.time()},
            'nodes': list(nodes.values()),
            'edges': edges
        }

        with open(Config.OUTPUT_FILE, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2)
        logger.info(f"Output saved to: {Config.OUTPUT_FILE}")