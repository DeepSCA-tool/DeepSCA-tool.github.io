

import sys
import os
from src.analyzer import ProjectAnalyzer


def main():

    target_dir = r"C:\Users\Desktop\c_repos\cnl"

    if len(sys.argv) > 1:
        target_dir = sys.argv[1]

    if not os.path.exists(target_dir):
        return

    analyzer = ProjectAnalyzer(target_dir)
    analyzer.run()


if __name__ == "__main__":
    main()
