"""
Test driver for component_identify functionality
Note: This tests the complete detection code using the family feature library
"""
import json
import math
import multiprocessing
import os
import traceback
import argparse
from tqdm import tqdm
from pathlib import Path
import time

# Assuming these are available in your environment
from src.component_detect_enhance.component_identification.automated_verification import Verification
from src.component_detect_enhance.component_identification.component_detector import Detector
from src.common_utils.utils_file import write_line_jl
from src.operate_db.test.GT import GroundTruth

class Test3rd:
    GT = GroundTruth()

    def split_list(self, full_list, n):
        """
        Split data into n equal parts and distribute to n threads/processes.

        :param full_list: The original complete list
        :param n: Number of splits (i.e., number of threads)
        :return: Yields the split list segments
        """
        step_count = math.ceil(len(full_list) / n)
        for i in range(0, len(full_list), step_count):
            end = i + step_count
            if end > len(full_list):
                end = len(full_list)
            # print(f"yield: {i}:{end}")
            yield full_list[i:end]

    def test_main(self, idx, list_arr, func_theta, file_theta, oss_theta, result_path, base_src_dir):
        """
        Worker function for processing a batch of projects.
        """
        detector = Detector(func_theta, file_theta, oss_theta)

        # Convert base_src_dir to Path object if it's a string
        base_path_obj = Path(base_src_dir)

        for projectname in list_arr:
            try:
                src_path = base_path_obj / projectname

                if not src_path.exists():
                    print(f"⚠️ Source path does not exist: {src_path}")
                    continue

                # Note: detector.hashing() requires a string path
                # (Most os.walk functions accept Path, but converting to str for safety)
                resDict, fileCnt, funcCnt, lineCnt = detector.hashing(str(src_path))

                final_res = detector.detector_main(resDict, 8)

                if final_res is not None:
                    # Record the final detection results
                    # Ensure the result directory exists
                    os.makedirs(result_path, exist_ok=True)

                    write_line_jl(os.path.join(result_path, projectname + "_components.jl"), final_res)
                    print(f"{projectname} has results")
            except Exception as e:
                print(f"Error: {str(e)}")
                traceback.print_exc()

    def main(self, num, func_theta, file_theta, oss_theta, source_dir, result_dir):
        base_src_path = Path(source_dir)

        # Automatically get all subdirectory names as project names (directories only, ignoring hidden files)
        if not base_src_path.exists():
            raise FileNotFoundError(f"Source code directory does not exist: {base_src_path}")

        allprojects = [
            item.name
            for item in base_src_path.iterdir()
            if item.is_dir() and not item.name.startswith('.')
        ]

        print(f"Detected {len(allprojects)} projects: {allprojects}")

        processes = []
        # Split task list and get process ID
        for idx, list_arr in enumerate(self.split_list(allprojects, num)):
            process = multiprocessing.Process(
                target=self.test_main,
                args=(
                    idx + 1,
                    list_arr,
                    func_theta,
                    file_theta,
                    oss_theta,
                    result_dir,   # Pass result path
                    source_dir    # Pass source path
                )
            )
            processes.append(process)

        for process in processes:
            process.start()

        for process in processes:
            process.join()  # Wait for all child processes to finish before executing main process code

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Component Identification Test Driver")

    # Path arguments
    parser.add_argument("--source_dir", "-s", type=str, required=True,
                        help=r"Path to the source code directory (e.g., C:\Users\...\c_project)")
    parser.add_argument("--result_dir", "-r", type=str, required=True,
                        help="Path where result files will be saved")

    # Parameter arguments (with defaults)
    parser.add_argument("--workers", "-w", type=int, default=4,
                        help="Number of worker processes (default: 4)")
    parser.add_argument("--func_theta", type=float, default=0.1,
                        help="Function threshold (default: 0.1)")
    parser.add_argument("--file_theta", type=float, default=0.7,
                        help="File threshold (default: 0.7)")
    parser.add_argument("--oss_theta", type=float, default=0.6,
                        help="OSS threshold (default: 0.6)")

    args = parser.parse_args()

    test3rd = Test3rd()

    print(f"Starting test with:")
    print(f"  Source: {args.source_dir}")
    print(f"  Output: {args.result_dir}")
    print(f"  Workers: {args.workers}")
    print(f"  Params: func={args.func_theta}, file={args.file_theta}, oss={args.oss_theta}")

    test3rd.main(
        num=args.workers,
        func_theta=args.func_theta,
        file_theta=args.file_theta,
        oss_theta=args.oss_theta,
        source_dir=args.source_dir,
        result_dir=args.result_dir
    )